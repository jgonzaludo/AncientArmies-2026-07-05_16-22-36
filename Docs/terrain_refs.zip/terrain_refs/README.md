# Ancient Armies terrain reference pack

Made 2026-11-07. Everything here is from our own game; no other game's
screenshots are included (not ours to bundle).

- `chatgpt_prompts.md`: style block plus 8 prompts. Start here.
- `palette.png`: the colours in the game today, plus NEW terrain colours (proposed)
  (my suggestions, not decided).
- `current_game/`: fresh captures of the game as it is now (HUD polish
  included), editor view 1573x860:
  - `1_hud_battle.png`: HUD with a selected unit and move orders
  - `2_zoom_near.png`, `3_zoom_mid.png`, `4_zoom_far.png`: the three camera
    zooms, mid-battle, on the current flat sand ground

What to match: chunky rounded soldiers, matte soft shading, low visual noise,
warm earthy ground, blue and red as the strongest colours on screen.
What to change: the flat sand ground and the empty field.

Closest outside references to look up yourself (search images, do not copy):
Bad North, Kingdom Rush, and tabletop miniature battle photos.
