# Ancient Armies: terrain mockup prompts (for ChatGPT image generation)

How to use: attach the images in `current_game/` and `palette.png` to the
chat first, paste the STYLE BLOCK, then paste one prompt at a time. Ask for
"4 variations" if you want options. Keep every image in landscape.

These are mockups to react to. Nothing here goes into the game folders until
you approve it.

## STYLE BLOCK (paste first, every time)

Match the attached game screenshots exactly in style. This is a stylized
mobile tactical strategy game that looks like a beautifully painted tabletop
miniature army seen from above, not photoreal and not cartoon.

- Camera: fixed isometric orthographic view, looking down at about 45 degrees,
  far enough away that tiny soldiers read as small rounded figures.
- Shapes: chunky, rounded, soft-beveled, solid and weighty. Low-poly forms
  with smooth matte shading. Large clean shapes beat busy detail.
- Low visual noise: no grass blades, no fine textures, no thin twigs, no
  realistic photo textures. If a detail would vanish at gameplay distance,
  leave it out.
- Surface: matte, soft broad lighting from one direction with gentle shadows,
  warm and slightly muted colours. No harsh specular shine, no dramatic fog.
- Palette: stay near the attached palette. Ground is warm and earthy; team
  colours (blue and red) are the strongest colours in the picture so units
  and banners always stand out.
- No text, no UI, no logos, no watermarks, no people close up.
- Do not copy any specific existing game. Original design only.

## 1. Hero battlefield (the target look)

A wide battlefield seen in the same isometric view as the screenshots. Two
armies of tiny blue and red soldiers in square blocks, with the blue and red
shield banners above them, facing each other across open grassy ground. Add a
dirt road crossing the field, a patch of mud, a small stream with a shallow
crossing, a few rocks, and one light clump of trees on the left edge. The
ground must be calm and low-contrast so the armies read first.

## 2. Ground materials sheet

A flat top-down swatch sheet, six large rounded tiles on a neutral
background, each labelled in your head but with NO text in the image: open
grass, packed dirt road, wet mud, shallow water (see-through, sandy bottom),
deep water (darker, calm), grey rock ground. Same soft matte look, very
gentle painterly variation, no repeating-pattern artefacts.

## 3. Trees set

A lineup of game-ready tree props on a plain light background, isometric view,
each a chunky rounded low-poly shape with a short thick trunk: broadleaf tree,
tall pine, small round bush, dead bare tree, and a stump with a fallen log.
Three sizes of the broadleaf tree. Leaves are big soft clumps, not individual
leaves. Greens slightly muted and warm.

## 4. Rocks and cliffs

A lineup of chunky rounded low-poly rocks on a plain light background: a
small boulder, a large boulder, a cluster of three, a flat slab, and two
cliff-edge pieces that could line the side of a river. Grey with a warm tint,
soft bevels, no sharp edges.

## 5. River, ford and bridge

An isometric section of the battlefield showing a river running across the
frame. It has deep calm water with soft darker centre, lighter shallow water
at the edges, one shallow ford (visible stepping stones, sandy bed), and one
narrow wooden bridge wide enough for a block of about twelve soldiers across.
Small armies of tiny blue soldiers on one bank and red on the other so scale
is clear. Banks are rounded and chunky, not realistic.

## 6. Forest zone readability test

A dense patch of the same chunky trees with a block of blue soldiers and a
blue banner inside it. Show two versions side by side: trees at full
opacity, and trees faded to about 40 percent near the soldiers so the unit
can still be seen and tapped. The banner must stay clear in both.

## 7. Props for later

A lineup of small set-dressing props in the same style: wooden fence
segments, haystack, a ruined stone wall, a market-style tent, a campfire, a
wooden cart. Chunky, rounded, soft-bevelled, very simple.

## 8. Lighting mood (later, not for this build)

The hero battlefield from prompt 1, repeated in three moods: soft morning
with long low shadows, overcast with gentle rain streaks, and golden
afternoon with light beams through trees. Keep the same flat readable
ground; only the light and atmosphere change.
